print ("Palmeiras não é o melhor do Brasil!!!! ")
print ("Palmeiras não é o melhor do Brasil!!!! ")